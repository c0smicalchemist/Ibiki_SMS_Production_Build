import{c as n,G as L,j as e,a as z,u as C,b as q,r as b,L as I,q as o}from"./index-BZOOS5ke.js";import{l as R,L as T}from"./Yubin_Dash_NOBG_1763476645991-B3uVJZ1d.js";import{B as l}from"./button-oirysK48.js";import{B as j}from"./badge-Bwtj-0Oo.js";import{u as M}from"./useQuery-DaBnOGW1.js";import{U as K}from"./users-CAxvfvkf.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J=n("ChevronUp",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=n("Inbox",[["polyline",{points:"22 12 16 12 14 15 10 15 8 12 2 12",key:"o97t9d"}],["path",{d:"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",key:"oot6mr"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q=n("List",[["path",{d:"M3 12h.01",key:"nlz23k"}],["path",{d:"M3 18h.01",key:"1tta3j"}],["path",{d:"M3 6h.01",key:"1rqtza"}],["path",{d:"M8 12h13",key:"1za7za"}],["path",{d:"M8 18h13",key:"1lx6n3"}],["path",{d:"M8 6h13",key:"ik3vkj"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U=n("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W=n("Moon",[["path",{d:"M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z",key:"a7tn18"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=n("RefreshCcw",[["path",{d:"M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"14sxne"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}],["path",{d:"M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16",key:"1hlbsb"}],["path",{d:"M16 16h5v5",key:"ccwih5"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=n("Send",[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=n("Sun",[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]]);function D(){const{theme:r,setTheme:h}=L();return e.jsxs("div",{className:"flex items-center gap-2 bg-muted rounded-md p-1",children:[e.jsxs(l,{variant:r==="light"?"default":"ghost",size:"sm",onClick:()=>h("light"),className:"h-8 px-3 gap-2","data-testid":"button-theme-light","aria-pressed":r==="light",children:[e.jsx(H,{className:"h-4 w-4"}),e.jsx("span",{className:"text-xs font-medium",children:"Light"})]}),e.jsxs(l,{variant:r==="dark"?"default":"ghost",size:"sm",onClick:()=>h("dark"),className:"h-8 px-3 gap-2","data-testid":"button-theme-dark","aria-pressed":r==="dark",children:[e.jsx(W,{className:"h-4 w-4"}),e.jsx("span",{className:"text-xs font-medium",children:"Dark"})]})]})}function X(){var g,k,f;const[r,h]=z(),{t:m}=C(),{toast:p}=q(),[x,y]=b.useState(!1),[E,O]=b.useState(!1),{data:t}=M({queryKey:["/api/client/profile"]}),{data:u}=M({queryKey:["/api/web/account/balance"],staleTime:1e4}),w=()=>{localStorage.removeItem("token"),h("/")},N=async()=>{y(!0);const a=[["/api/client/profile"],["/api/client/messages"],["/api/client/inbox"],["/api/v2/sms/messages"],["/api/v2/sms/inbox"],["/api/message-status-stats"],["/api/admin/clients"],["/api/admin/stats"],["/api/admin/recent-activity"],["/api/admin/error-logs"],["/api/admin/config"],["/api/web/inbox"]],s=localStorage.getItem("selectedClientId"),c=!(localStorage.getItem("isAdminMode")==="true")&&s?s:void 0,S=[["/api/contacts",c],["/api/contact-groups",c],["/api/contacts/sync-stats",c]];for(const i of a)await o.invalidateQueries({queryKey:i}),await o.refetchQueries({queryKey:i});for(const i of S)await o.invalidateQueries({queryKey:i}),await o.refetchQueries({queryKey:i});await o.invalidateQueries({predicate:i=>{var d;return String(((d=i.queryKey)==null?void 0:d[0])||"").startsWith("/api/")}}),await o.refetchQueries({predicate:i=>{var d;return String(((d=i.queryKey)==null?void 0:d[0])||"").startsWith("/api/")}}),y(!1),p({title:m("common.success"),description:"Refresh successful"})};return e.jsxs("header",{className:"border-b border-border bg-background",children:[e.jsxs("div",{className:"flex items-center justify-between h-16 px-6",children:[e.jsxs("div",{className:"flex items-center gap-3",children:[e.jsx(I,{href:"/",children:e.jsx("img",{src:R,alt:"Yubin Dash",className:"h-10 w-auto cursor-pointer"})}),(()=>{const a=String(r),s=a.startsWith("/send-sms")?"send":a.startsWith("/inbox")?"inbox":a.startsWith("/contacts")?"contacts":a.startsWith("/message-history")?"history":"";if(!s)return null;const v=s==="send"?F:s==="inbox"?A:s==="contacts"?K:Q,c=s==="send"?"Send SMS":s==="inbox"?"Inbox":s==="contacts"?"Contacts":"Message History";return e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(v,{className:"h-4 w-4 text-muted-foreground"}),e.jsx("span",{className:"text-base font-semibold text-muted-foreground",children:c})]})})()]}),e.jsxs("div",{className:"flex items-center gap-3",children:[((g=t==null?void 0:t.user)==null?void 0:g.name)&&e.jsxs(j,{variant:"secondary","data-testid":"badge-username",children:[t.user.name,typeof(u==null?void 0:u.balance)=="number"?` · Credits ${u.balance.toFixed(2)}`:""]}),((k=t==null?void 0:t.user)==null?void 0:k.role)&&e.jsx(j,{variant:"outline","data-testid":"badge-role",children:t.user.role==="admin"?"Admin":t.user.role==="supervisor"?"Supervisor":"User"}),e.jsx(D,{}),e.jsx(T,{}),e.jsxs(l,{variant:"ghost",size:"sm",onClick:N,"data-testid":"button-refresh",children:[e.jsx(B,{className:`mr-2 h-4 w-4 ${x?"animate-spin":""}`}),x?"Refreshing…":"Refresh"]}),((f=t==null?void 0:t.user)==null?void 0:f.role)==="admin"&&e.jsx(l,{variant:"ghost",size:"sm",onClick:async()=>{try{const a=localStorage.getItem("token");if(!(await fetch("/api/admin/auth/invalidate",{method:"POST",headers:{"Content-Type":"application/json",...a?{Authorization:`Bearer ${a}`}:{}}})).ok)throw new Error("Failed");p({title:m("common.success"),description:"All sessions invalidated"})}catch{p({title:m("common.error"),description:"Failed to invalidate tokens",variant:"destructive"})}},children:"Force Refresh Tokens"}),e.jsxs(l,{variant:"ghost",size:"sm",onClick:w,"data-testid":"button-logout",children:[e.jsx(U,{className:"mr-2 h-4 w-4"}),m("nav.logout")]})]})]}),e.jsx("div",{className:"px-6 pb-2",children:e.jsx("div",{className:"text-xs text-muted-foreground"})})]})}export{J as C,X as D,A as I,Q as L,F as S};
