import{c as r,r as s,Q as o,t as u}from"./index-CW4K8Dxr.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=r("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);var n=o[" useId ".trim().toString()]||(()=>{}),d=0;function p(t){const[e,a]=s.useState(n());return u(()=>{a(c=>c??String(d++))},[t]),t||(e?`radix-${e}`:"")}export{f as C,p as u};
