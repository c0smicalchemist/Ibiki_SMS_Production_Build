import{c as D,r as y,j as e,u as f,L as E}from"./index-C2lczEwA.js";import{A as b,a as j}from"./alert-B18oqM0Z.js";import{C as p,b as x,a as h,c as u,d as g}from"./card-C4sqVH89.js";import{B as T,C as $}from"./badge-w9Ci-Rp2.js";import{R as A,C as S,a as I}from"./index-7CLrnR0X.js";import{B as v}from"./button-B8SzJzTc.js";import{C as _}from"./index-CQBk5xQS.js";import{C as P}from"./copy-BG0TcTZC.js";import{C as m}from"./circle-check-CVfOefbx.js";import{C as O}from"./circle-alert-jocfoy6B.js";import{u as R}from"./useQuery-B1xKiAId.js";import{A as B}from"./arrow-left-qcNO8I30.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=D("Info",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]]),q=A,Y=S,X=I;function N({code:s,language:a="bash"}){const[n,c]=y.useState(!1),r=async i=>{try{if(navigator.clipboard&&window.isSecureContext&&typeof navigator.clipboard.writeText=="function")return await navigator.clipboard.writeText(i),!0}catch{}const o=document.createElement("textarea");o.value=i,o.style.position="fixed",o.style.opacity="0",document.body.appendChild(o),o.focus(),o.select();let l=!1;try{l=document.execCommand("copy")}catch{}if(!l){const d=k=>{var w;k.preventDefault(),(w=k.clipboardData)==null||w.setData("text/plain",i)};document.addEventListener("copy",d);try{l=document.execCommand("copy")}catch{}document.removeEventListener("copy",d)}return document.body.removeChild(o),l},t=async()=>{await r(s)&&(c(!0),setTimeout(()=>c(!1),2e3))};return e.jsxs("div",{className:"relative group",children:[e.jsx("div",{className:"absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity",children:e.jsx(v,{size:"sm",variant:"ghost",onClick:t,className:"h-8","data-testid":"button-copy-code",children:n?e.jsx(_,{className:"w-4 h-4"}):e.jsx(P,{className:"w-4 h-4"})})}),e.jsx("pre",{className:"bg-card border border-card-border rounded-lg p-4 overflow-x-hidden",children:e.jsx("code",{className:"text-sm font-mono text-foreground whitespace-pre-wrap break-words",children:s})})]})}function H({method:s,path:a,title:n,description:c,requestExample:r,responseExample:t}){const[i,o]=y.useState(!1),{t:l}=f(),d={GET:"bg-blue-500/10 text-blue-600 dark:text-blue-400",POST:"bg-green-500/10 text-green-600 dark:text-green-400",PUT:"bg-yellow-500/10 text-yellow-600 dark:text-yellow-400",DELETE:"bg-red-500/10 text-red-600 dark:text-red-400"};return e.jsx(p,{"data-testid":`card-endpoint-${s.toLowerCase()}-${a.replace(/\//g,"-")}`,children:e.jsxs(q,{open:i,onOpenChange:o,children:[e.jsx(Y,{className:"w-full","data-testid":`button-toggle-${s.toLowerCase()}-${a.replace(/\//g,"-")}`,children:e.jsxs(x,{className:"flex flex-row items-center justify-between gap-4 space-y-0",children:[e.jsxs("div",{className:"flex items-center gap-3 flex-1",children:[e.jsx(T,{className:d[s],"data-testid":`badge-method-${s.toLowerCase()}`,children:s}),e.jsx("code",{className:"font-mono text-sm flex-1 text-left",children:a})]}),e.jsx($,{className:`w-5 h-5 text-muted-foreground transition-transform ${i?"rotate-180":""}`})]})}),e.jsxs(h,{className:"pt-0",children:[e.jsx(u,{className:"text-lg mb-2",children:n}),e.jsx(g,{className:"mb-4",children:c}),e.jsxs(X,{children:[r&&e.jsxs("div",{className:"space-y-2 mb-4",children:[e.jsx("p",{className:"text-sm font-medium",children:l("api.requestExample")}),e.jsx(N,{code:r})]}),t&&e.jsxs("div",{className:"space-y-2",children:[e.jsx("p",{className:"text-sm font-medium",children:l("api.responseExample")}),e.jsx(N,{code:t,language:"json"})]})]})]})]})})}function z(){const{t:s}=f();return e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"text-2xl font-semibold mb-4",children:s("webhookDocs.title")}),e.jsx("p",{className:"text-muted-foreground",children:s("webhookDocs.subtitle")})]}),e.jsxs(p,{children:[e.jsxs(x,{children:[e.jsx(u,{className:"text-lg",children:s("webhookDocs.ibiki.title")}),e.jsx(g,{children:s("webhookDocs.ibiki.description")})]}),e.jsxs(h,{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold mb-2",children:s("webhookDocs.ibiki.setupTitle")}),e.jsxs("ol",{className:"list-decimal list-inside space-y-2 text-sm",children:[e.jsx("li",{children:s("webhookDocs.ibiki.step1")}),e.jsx("li",{children:s("webhookDocs.ibiki.step2")}),e.jsx("li",{children:s("webhookDocs.ibiki.step3")}),e.jsx("li",{children:s("webhookDocs.ibiki.step4")}),e.jsx("li",{children:s("webhookDocs.ibiki.step5")}),e.jsx("li",{children:s("webhookDocs.ibiki.step6")})]})]}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold mb-2",children:s("webhookDocs.ibiki.payloadTitle")}),e.jsx("pre",{className:"bg-muted p-3 rounded text-xs font-mono overflow-x-auto",children:`{
  "from": "+12345678901",
  "firstname": "John",
  "lastname": "Doe",
  "business": "ABC Company",
  "message": "Reply message text",
  "status": "received",
  "matchedBlockWord": "null",
  "receiver": "+19876543210",
  "usedmodem": "modem_id",
  "port": "port_number",
  "timestamp": "2025-11-19T10:30:00.000Z",
  "messageId": "unique_msg_id"
}`})]})]})]}),e.jsxs(p,{className:"border-primary",children:[e.jsxs(x,{children:[e.jsxs(u,{className:"text-lg flex items-center gap-2",children:[e.jsx(m,{className:"h-5 w-5 text-primary"}),s("webhookDocs.ibiki.title")]}),e.jsx(g,{children:s("webhookDocs.ibiki.description")})]}),e.jsxs(h,{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold mb-3",children:s("webhookDocs.ibiki.howItWorks")}),e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{className:"flex gap-3",children:[e.jsx(m,{className:"h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5"}),e.jsxs("div",{children:[e.jsx("p",{className:"font-medium text-sm",children:s("webhookDocs.ibiki.automaticTitle")}),e.jsx("p",{className:"text-sm text-muted-foreground",children:s("webhookDocs.ibiki.automaticDesc")})]})]}),e.jsxs("div",{className:"flex gap-3",children:[e.jsx(m,{className:"h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5"}),e.jsxs("div",{children:[e.jsx("p",{className:"font-medium text-sm",children:s("webhookDocs.ibiki.multipleTitle")}),e.jsx("p",{className:"text-sm text-muted-foreground",children:s("webhookDocs.ibiki.multipleDesc")})]})]}),e.jsxs("div",{className:"flex gap-3",children:[e.jsx(m,{className:"h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5"}),e.jsxs("div",{children:[e.jsx("p",{className:"font-medium text-sm",children:s("webhookDocs.ibiki.dashboardTitle")}),e.jsx("p",{className:"text-sm text-muted-foreground",children:s("webhookDocs.ibiki.dashboardDesc")})]})]})]})]}),e.jsxs("div",{children:[e.jsx("h4",{className:"font-semibold mb-3",children:s("webhookDocs.ibiki.routingTitle")}),e.jsxs("div",{className:"bg-muted/50 p-4 rounded-lg space-y-3 text-sm",children:[e.jsxs("div",{className:"flex items-start gap-2",children:[e.jsx("span",{className:"font-bold text-primary",children:"1."}),e.jsx("p",{children:s("webhookDocs.ibiki.routing1")})]}),e.jsxs("div",{className:"flex items-start gap-2",children:[e.jsx("span",{className:"font-bold text-primary",children:"2."}),e.jsx("p",{children:s("webhookDocs.ibiki.routing2")})]}),e.jsxs("div",{className:"flex items-start gap-2",children:[e.jsx("span",{className:"font-bold text-primary",children:"3."}),e.jsx("p",{children:s("webhookDocs.ibiki.routing3")})]}),e.jsxs("div",{className:"flex items-start gap-2",children:[e.jsx("span",{className:"font-bold text-primary",children:"4."}),e.jsx("p",{children:s("webhookDocs.ibiki.routing4")})]}),e.jsxs("div",{className:"flex items-start gap-2",children:[e.jsx("span",{className:"font-bold text-primary",children:"5."}),e.jsx("p",{children:s("webhookDocs.ibiki.routing5")})]})]})]}),e.jsxs(b,{children:[e.jsx(O,{className:"h-4 w-4"}),e.jsxs(j,{className:"text-sm",children:[e.jsx("strong",{children:s("webhookDocs.ibiki.importantTitle")})," ",s("webhookDocs.ibiki.importantDesc")]})]})]})]}),e.jsxs(b,{children:[e.jsx(C,{className:"w-4 h-4"}),e.jsx(j,{children:e.jsxs("div",{className:"space-y-2",children:[e.jsx("p",{className:"font-semibold",children:s("webhookDocs.webhook.configTitle")}),e.jsx("code",{className:"block bg-muted p-3 rounded text-sm font-mono",children:"http://151.243.109.79/webhook/incoming-sms"}),e.jsx("p",{className:"text-xs text-muted-foreground",children:s("webhookDocs.webhook.configDesc")})]})})]})]})}function se(){var r;const{t:s}=f(),{data:a}=R({queryKey:["/api/client/profile"]}),n=((r=a==null?void 0:a.user)==null?void 0:r.role)==="admin",c=[{method:"POST",path:"/api/web/sms/send-single",title:"Send Single",description:"Send a single SMS to one recipient",requestExample:`curl -X POST https://ibiki.run.place/api/web/sms/send-single \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"recipient": "${s("examples.phone.sample1")}", "message": "${s("examples.sms.verificationCode")}"}'`,responseExample:`{
  "success": true,
  "messageId": "60f1a5b3e6e7c12345678901",
  "status": "queued"
}`},{method:"POST",path:"/api/v2/sms/reply",title:"Reply (Helper)",description:"Reply to a conversation; modem/port mapped from last inbound",requestExample:`curl -X POST https://ibiki.run.place/api/v2/sms/reply \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
  "to": "${s("examples.phone.sample1")}",
  "message": "${s("examples.sms.verificationCode")}"
}'`,responseExample:`{
  "success": true,
  "provider": { "status": "queued" }
}`},{method:"POST",path:"/api/web/sms/send-bulk",title:"Send Bulk",description:"Send the same SMS to multiple recipients",requestExample:`curl -X POST https://ibiki.run.place/api/web/sms/send-bulk \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
  "recipients": ["${s("examples.phone.sample1")}", "${s("examples.phone.sample2")}"],
  "message": "${s("examples.sms.orderShipped")}"
}'`,responseExample:`{
  "success": true,
  "messageIds": ["60f1a5b3e6e7c12345678901", "60f1a5b3e6e7c12345678902"],
  "totalSent": 2,
  "status": "queued"
}`},{method:"POST",path:"/api/web/sms/send-bulk-multi",title:"Send Bulk Multi",description:"Send different messages to multiple recipients in one request",requestExample:`curl -X POST https://ibiki.run.place/api/web/sms/send-bulk-multi \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '[
  {"to": "${s("examples.phone.sample1")}", "message": "${s("examples.sms.verificationCode")}"},
  {"to": "${s("examples.phone.sample2")}", "message": "${s("examples.sms.orderShipped")}"}
]'`,responseExample:`{
  "success": true,
  "results": [
    {"messageId": "60f1a5b3e6e7c12345678901", "recipient": "${s("examples.phone.sample1")}", "status": "queued"}
  ],
  "totalSent": 2,
  "totalFailed": 0
}`},{method:"GET",path:"/api/web/sms/messages",title:"Get All Sent Messages",description:"Retrieve all messages sent by your account with their status. Returns up to 100 messages by default. Use the 'limit' query parameter to control the number of messages returned.",requestExample:`curl -X GET "https://ibiki.run.place/api/web/sms/messages?limit=50" \\
  -H "Authorization: Bearer YOUR_API_KEY"`,responseExample:`{
  "success": true,
  "messages": [
    {
      "id": "msg_abc123",
      "messageId": "60f1a5b3e6e7c12345678901",
      "endpoint": "sendsingle",
      "recipient": "${s("examples.phone.sample1")}",
      "status": "delivered",
      "totalCost": "0.05",
      "totalCharge": "0.10",
      "messageCount": 1,
      "createdAt": "2025-11-18T10:30:00.000Z"
    }
  ],
  "count": 1,
  "limit": 50
}`},{method:"GET",path:"/api/web/sms/status/{messageId}",title:"Check Delivery",description:"Get the delivery status for a specific messageId",requestExample:`curl -X GET https://ibiki.run.place/api/web/sms/status/60f1a5b3e6e7c12345678901 \\
  -H "Authorization: Bearer YOUR_API_KEY"`,responseExample:`{
  "success": true,
  "messageId": "60f1a5b3e6e7c12345678901",
  "status": "delivered",
  "deliveredAt": "2025-09-17T16:30:00.000Z"
}`},{method:"GET",path:"/api/web/account/balance",title:"Check Balance",description:"Get your current credits balance",requestExample:`curl -X GET https://ibiki.run.place/api/web/account/balance \\
  -H "Authorization: Bearer YOUR_API_KEY"`,responseExample:`{
  "success": true,
  "balance": 250,
  "currency": "credits"
}`},{method:"GET",path:"/api/web/sms/inbox",title:"Inbox",description:"Retrieve recent inbound messages to your account",requestExample:`curl -X GET https://ibiki.run.place/api/web/sms/inbox?limit=50 \\
  -H "Authorization: Bearer YOUR_API_KEY"`,responseExample:`{
  "success": true,
  "messages": [
    {
      "id": "abc123",
      "from": "${s("examples.phone.sample1")}",
      "firstname": "${s("examples.name.first")}",
      "lastname": "${s("examples.name.last")}",
      "business": "${s("examples.company")}",
      "message": "${s("examples.sms.reply")}",
      "status": "received",
      "receiver": "${s("examples.phone.sample2")}",
      "timestamp": "2025-11-18T10:30:00.000Z",
      "messageId": "ext_msg_123"
    }
  ],
  "count": 1
}`}];return s("docs.webhook.title"),s("docs.webhook.description"),`${s("examples.phone.sample1")}${s("examples.name.first")}${s("examples.name.last")}${s("examples.company")}${s("examples.sms.stopMessage")}${s("examples.phone.sample2")}`,e.jsxs("div",{className:"p-6 space-y-8 max-w-5xl",children:[e.jsxs("div",{className:"flex items-center gap-4",children:[e.jsx(E,{href:"/dashboard",children:e.jsx(v,{size:"icon","data-testid":"button-back",className:"bg-blue-600 text-white hover:bg-blue-700 font-bold",children:e.jsx(B,{className:"h-5 w-5",strokeWidth:3})})}),e.jsxs("div",{children:[e.jsx("h1",{className:"text-4xl font-bold tracking-tight",children:s("docs.title")}),e.jsx("p",{className:"text-muted-foreground mt-2",children:s("docs.subtitle")})]})]}),e.jsxs(b,{"data-testid":"alert-authentication",children:[e.jsx(C,{className:"w-4 h-4"}),e.jsxs(j,{children:[e.jsx("strong",{children:s("docs.authentication.strong")})," ",s("docs.authentication.description"),e.jsx("code",{className:"block mt-2 bg-muted p-2 rounded text-sm font-mono",children:"Authorization: Bearer YOUR_API_KEY"})]})]}),e.jsxs("div",{className:"space-y-6",children:[e.jsx("h2",{className:"text-2xl font-semibold",children:s("docs.endpoints.title")}),c.map((t,i)=>e.jsx(H,{...t},i))]}),n?e.jsx("div",{className:"mt-12",children:e.jsx(z,{})}):e.jsxs("div",{className:"mt-12",children:[e.jsx("h2",{className:"text-2xl font-semibold",children:"API Error Codes"}),e.jsx("div",{className:"mt-4 grid grid-cols-2 md:grid-cols-3 gap-3",children:[{code:200,status:"OK"},{code:400,status:"Bad Request"},{code:401,status:"Unauthorized"},{code:402,status:"Payment Required"},{code:404,status:"Not Found"},{code:429,status:"Too Many Requests"},{code:500,status:"Internal Server Error"}].map(t=>e.jsxs(p,{className:"border border-border/60",children:[e.jsx(x,{className:"py-3",children:e.jsxs(u,{className:"flex items-center justify-between",children:[e.jsx("span",{className:"font-mono text-lg",children:t.code}),e.jsx("span",{className:"text-sm text-muted-foreground",children:t.status})]})}),e.jsx(h,{className:"py-0"})]},t.code))})]})]})}export{se as default};
