import{c as t,j as n,h as a,v as s}from"./index-BQlTG-Xl.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=t("ChevronDown",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]),d=s("whitespace-nowrap inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 hover-elevate ",{variants:{variant:{default:"border-transparent bg-primary text-primary-foreground shadow-xs",secondary:"border-transparent bg-secondary text-secondary-foreground",destructive:"border-transparent bg-destructive text-destructive-foreground shadow-xs",outline:" border [border-color:var(--badge-outline)] shadow-xs"}},defaultVariants:{variant:"default"}});function u({className:r,variant:e,...o}){return n.jsx("div",{className:a(d({variant:e}),r),...o})}export{u as B,c as C};
